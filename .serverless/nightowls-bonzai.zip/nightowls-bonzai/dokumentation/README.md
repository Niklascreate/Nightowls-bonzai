POST Rooms:

[
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    { "roomType": "singleroom", "price": 500 },
    
    { "roomType": "doubleroom", "price": 1000 },
    { "roomType": "doubleroom", "price": 1000 },
    { "roomType": "doubleroom", "price": 1000 },
    { "roomType": "doubleroom", "price": 1000 },
    { "roomType": "doubleroom", "price": 1000 },

    { "roomType": "suiteroom", "price": 1500 },
    { "roomType": "suiteroom", "price": 1500 },
    { "roomType": "suiteroom", "price": 1500 },
    { "roomType": "suiteroom", "price": 1500 },
    { "roomType": "suiteroom", "price": 1500 }
]

